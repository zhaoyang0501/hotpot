package seed.sys.service;
import org.springframework.stereotype.Service;

import seed.common.service.SimpleCurdService;
import seed.sys.entity.Action;

@Service
public class ActionService extends SimpleCurdService<Action, Long> {
	
	
	
}
