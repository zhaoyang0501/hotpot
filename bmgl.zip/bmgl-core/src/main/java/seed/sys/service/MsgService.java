package seed.sys.service;
import org.springframework.stereotype.Service;

import seed.common.service.SimpleCurdService;
import seed.sys.entity.Msg;

@Service
public class MsgService extends SimpleCurdService<Msg, Long> {
	
}
