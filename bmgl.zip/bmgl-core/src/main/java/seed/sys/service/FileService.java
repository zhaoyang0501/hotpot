package seed.sys.service;
import org.springframework.stereotype.Service;

import seed.common.service.SimpleCurdService;
import seed.sys.entity.File;

@Service
public class FileService extends SimpleCurdService<File, Long> {
	
}
