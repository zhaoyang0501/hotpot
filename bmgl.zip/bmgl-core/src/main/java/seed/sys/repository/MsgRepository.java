package seed.sys.repository;
import seed.common.repository.SimpleCurdRepository;
import seed.sys.entity.Action;
import seed.sys.entity.Msg;
public interface MsgRepository   extends SimpleCurdRepository<Msg ,Long>{
}
