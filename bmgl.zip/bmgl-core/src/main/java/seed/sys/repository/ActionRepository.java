package seed.sys.repository;
import seed.common.repository.SimpleCurdRepository;
import seed.sys.entity.Action;
public interface ActionRepository   extends SimpleCurdRepository<Action ,Long>{
}
